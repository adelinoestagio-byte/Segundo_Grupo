<?php
include("conexao.php");

$numero = $_POST['numero'];
$tipo = $_POST['tipo'];
$estado = $_POST['estado'];

$sql = "INSERT INTO quartos (numero_quarto, id_tipo, status_quarto) VALUES ('$numero','$tipo','$estado')";

if($conn->query($sql) === TRUE){
    header("Location: index.php");
}else{
    echo "Erro: " . $conn->error;
}
?>
