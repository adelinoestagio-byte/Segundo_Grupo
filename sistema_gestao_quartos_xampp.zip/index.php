
<?php include("conexao.php"); ?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<title>Sistema de Gestão de Quartos</title>
<style>
body{font-family:Arial;background:#f4f6f9;margin:0}
header{background:#2c3e50;color:white;padding:15px;text-align:center}
.container{padding:20px}
.card{background:white;padding:20px;border-radius:8px;box-shadow:0 0 5px rgba(0,0,0,0.1)}
input,select{padding:8px;margin:5px}
button{padding:8px 15px;background:#27ae60;color:white;border:none;border-radius:4px}
table{width:100%;margin-top:20px;border-collapse:collapse}
th,td{border:1px solid #ddd;padding:10px;text-align:center}
th{background:#2c3e50;color:white}
</style>
</head>

<body>

<header>
<h2>Sistema de Gestão de Quartos</h2>
</header>

<div class="container">

<div class="card">

<h3>Adicionar Quarto</h3>

<form action="adicionar_quarto.php" method="POST">

<input type="text" name="numero" placeholder="Número do quarto" required>

<select name="tipo">
<option value="1">Normal</option>
<option value="2">Luxo</option>
<option value="3">Suite</option>
</select>

<select name="estado">
<option value="Disponivel">Disponível</option>
<option value="Ocupado">Ocupado</option>
<option value="Manutencao">Manutenção</option>
</select>

<button type="submit">Adicionar</button>

</form>

</div>

<div class="card">

<h3>Lista de Quartos</h3>

<table>
<tr>
<th>ID</th>
<th>Número</th>
<th>Status</th>
</tr>

<?php

$sql = "SELECT * FROM quartos";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

while($row = $result->fetch_assoc()) {

echo "<tr>";
echo "<td>".$row["id_quarto"]."</td>";
echo "<td>".$row["numero_quarto"]."</td>";
echo "<td>".$row["status_quarto"]."</td>";
echo "</tr>";

}

}

?>

</table>

</div>

</div>

</body>
</html>
